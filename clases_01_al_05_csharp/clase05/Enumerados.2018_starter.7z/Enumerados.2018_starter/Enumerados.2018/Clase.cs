﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumerados._2018
{
    class Clase
    {
        public int entero;

        public Clase(int entero)
        {
            this.entero = entero;
        }

        public void MetodoInstancia()
        {
            Console.WriteLine();
        }
    }
}
