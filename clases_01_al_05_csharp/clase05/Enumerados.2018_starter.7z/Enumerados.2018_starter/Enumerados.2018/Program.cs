﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumerados._2018
{
    class Program
    {
        static void Main(string[] args)
        {

            
            //como asignarlo
            

            //como parametros


            //como retorno


            //como recorrerlo

            
            //switch



        }




        private static void MetodoEstatico()
        {
            Console.WriteLine();
        }

    }
}
